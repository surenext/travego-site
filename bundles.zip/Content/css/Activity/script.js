$.ajax({
    type: "POST",
    url: "/Activity/GetBanners",
    data: "{}",
    async: true,
    contentType: "application/json; charset=utf-8",
    dataType: "html",
    success: function (r) {
        $("#act-banner").html(r);
        $("#destinations-iinput").autocomplete({
            minLength: 2,
            classes: {
                "ui-autocomplete": "dropdown-menu",
            },
            source: function (request, responce) {
                debugger;
                $.ajax({
                    url: "/Home/GetCityList",
                    type: "POST",
                    dataType: "json",
                    async: true,
                    data: { searchText: request.term, Type: 'Destination' },
                    success: function (data) {
                        var customer = new Array();
                        for (var i = 0; i < data.list.length; i++) {
                            customer[i] = { label: data.list[i].Name, Id: i };
                        }
                        responce(customer);
                    },
                    error: function (err) {
                        alert('error');
                    }
                });
            }
        }).data("ui-autocomplete")._renderItem = function (ul, item) {
            return $("<li></li>")
                .addClass(item.customClass) //item based custom class to li here
                .append("<a href='#'><i class='fa fa-map-marker icons small'></i> " + item.label + "</a>")
                .data("ui-autocomplete-item", item)
                .appendTo(ul);
        };
    }
});



$.ajax({
    type: "POST",
    url: "/Activity/GetActivities",
    data: "{}",
    async: true,
    contentType: "application/json; charset=utf-8",
    dataType: "html",
    success: function (r) {
        $("#act-section").html(r);
        $('#popular_destination').owlCarousel({
            loop: false,
            margin: 10,
            nav: false,
            dots: false,
         
            responsiveClass: true,
            responsive: {
                0: {
                    items: 2,
                    nav: false
                },
                600: {
                    items: 2,
                    nav: false
                },
                1000: {
                    items: 4,
                    nav:
                        false,
                    loop: false
                }
            }
        })
    }
});


$.ajax({
    type: "POST",
    url: "/Activity/GetDestinations",
    data: "{}",
    async: true,
    contentType: "application/json; charset=utf-8",
    dataType: "html",
    success: function (r) {
        $("#destination-section").html(r);
        $('#selling_activity').owlCarousel({
            loop: false,
            margin: 10,
            nav: false,
            dots: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 2,
                    nav: false
                },
                600: {
                    items: 2,
                    nav: false
                },
                1000: {
                    items: 4,
                    nav: false,
                    loop: false
                }
            }
        })
    }
});

$.ajax({
    type: "POST",
    url: "/Home/GetBlogs",
    data: "{}",
    async: true,
    contentType: "application/json; charset=utf-8",
    dataType: "html",
    success: function (r) {
        $("#blogs-section").html(r);
    }
});

