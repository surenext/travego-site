$.ajax({
    type: "POST",
    url: "/Home/GetBanners",
    data: "{}",
    async: true,
    contentType: "application/json; charset=utf-8",
    dataType: "html",
    success: function (r) {
        $("#holiday-banner").html(r);
        
        $.ajax({
            type: "POST",
            url: "/Home/GetDestinations",
            data: "{}",
            async: true,
            contentType: "application/json; charset=utf-8",
            dataType: "html",
            success: function (r) {
                $("#destination-section").html(r);
                $('.quick-destinations-section').owlCarousel({
                    loop: false,
                    margin: 10,
                    dots: false,
                    autoplay: false,

                    nav: false,
                    responsive: {
                        0: {
                            items: 1
                        },
                        600: {
                            items: 1
                        },
                        1000: {
                            items: 1
                        }
                    }
                })
            }
        });
        $.ajax({
            type: "POST",
            url: "/Home/GetPackages",
            data: "{}",
            async: true,
            contentType: "application/json; charset=utf-8",
            dataType: "html",
            success: function (r) {
                $("#holiday-section").html(r);
                $('.htlpackage').owlCarousel({
                    loop: true,
                    lazyLoad: true,
                    autoplay: true,
                    items: 5,
                    margin: 20,
                    dots: false,
                    center: false,
                    nav: true,
                    smartSpeed: 800,
                    responsive: {
                        0: {
                            items: 1,
                            stagePadding: 0,
                            nav: true,
                            center: true,
                        },
                        420: {
                            items: 1,
                            nav: true,
                            center: true,
                        },
                        600: {
                            items: 3,
                            nav: true,
                            center: true,
                        },


                        1000: {
                            items: 3,
                            nav: true,
                            center: true,
                        }
                    }
                })
            }
        });




        $.ajax({
            type: "POST",
            url: "/Home/GetTags",
            data: "{}",
            async: true,
            contentType: "application/json; charset=utf-8",
            dataType: "html",
            success: function (r) {
                $("#theme-section").html(r);
                $('.themeslider').owlCarousel({
                    loop: true,
                    margin: 10,
                    autoplay: true,
                    nav: false,
                    dots: false,
                    navText: ['<span class="fa fa-chevron-left icons"></span>',
                        '<span class="fa fa-chevron-right icons"></span>'
                    ],
                    center: false,
                    nav: true,
                    smartSpeed: 800,
                    responsiveClass: true,
                    responsive: {
                        0: {
                            items: 2,
                            nav: true
                        },
                        600: {
                            items: 2,
                            nav: false
                        },
                        1000: {
                            items: 6,
                            nav: true,
                            loop: false
                        }
                    }
                })
            }
        });
        $.ajax({
            type: "POST",
            url: "/Home/GetBlogs",
            data: "{}",
            async: true,
            contentType: "application/json; charset=utf-8",
            dataType: "html",
            success: function (r) {
                $("#blogs-section").html(r);
            }
        });

        $.ajax({
            type: "POST",
            url: "/Home/GetTestmonial",
            data: "{}",
            async: true,
            contentType: "application/json; charset=utf-8",
            dataType: "html",
            success: function (r) {
                $("#Testmonial-Section").html(r);
                $('.htlpackage').owlCarousel({
                    loop: true,
                    lazyLoad: true,
                    autoplay: true,
                    items: 5,
                    margin: 20,
                    dots: false,
                    center: false,
                    nav: true,
                    smartSpeed: 800,
                    responsive: {
                        0: {
                            items: 1,
                            stagePadding: 0,
                            nav: true,
                            center: true,
                        },
                        420: {
                            items: 1,
                            nav: true,
                            center: true,
                        },
                        600: {
                            items: 3,
                            nav: true,
                            center: true,
                        },


                        1000: {
                            items: 3,
                            nav: true,
                            center: true,
                        }
                    }
                })
            }
        });

        $.ajax({
            type: "POST",
            url: "/Home/NewLetter",
            data: "{}",
            async: true,
            contentType: "application/json; charset=utf-8",
            dataType: "html",
            success: function (r) {
                $("#NewsLetter-section").html(r);
            }
        });

        $.ajax({
            type: "POST",
            url: "/Home/GetOffers",
            data: "{}",
            async: true,
            contentType: "application/json; charset=utf-8",
            dataType: "html",
            success: function (r) {
                $("#offer-section").html(r);
                $('#banneroffer_Sec').owlCarousel({
                    loop: true,
                    lazyLoad: true,
                    autoplay: true,
                    items: 2,
                    margin: 20,
                    dots: false,

                    center: false,
                    nav: true,
                    smartSpeed: 800,
                    responsive: {
                        0: {
                            items: 2,
                            stagePadding: 0,
                            nav: false,
                        },
                        420: {
                            items: 1,
                            nav: false,
                        },
                        600: {
                            items: 1,
                        },
                        1000: {
                            items: 2
                        }
                    }
                });
            }
        });
    }
});

//offer section slider start//
$('.offerslider').owlCarousel({
    loop: false,
    margin: 10,
    nav: false,
    dots: false,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1,
            nav: true
        },
        600: {
            items: 2,
            nav: false
        },
        1000: {
            items: 2,
            nav: true,
            loop: false
        }
    }
})

function getAutoCom() {
    $.ajax({
        url: "/Home/GetCityList",
        type: "POST",
        dataType: "json",
        async: true,
        data: { searchText: document.getElementById("destinations-iinputs").value, Type: 'Package' },
        success: function (data) {
            var customer = new Array();
            for (var i = 0; i < data.list.length; i++) {
                customer[i] = { label: data.list[i].Name, Id: i };
            }

            $("#destinations-iinputs").autocomplete({
                source: customer
            });
        },
        error: function (err) {
            alert('error');
        }
    });
}

//traveller counter start//
function process(v) {
    var Adult = parseInt(document.getElementById("ddlAdult").value);
    var Child = parseInt(document.getElementById("ddlChild").value);
    var Infant = parseInt(document.getElementById("ddlInfant").value);
    Adult += v;
    var total = Adult + Child;
    if (total <= 9 && Adult >= 1) {
        document.getElementById("ddlAdult").value = Adult;
        if (Infant > Adult) {
            document.getElementById("ddlInfant").value = Adult;
        }
        var TotTravelers = Adult + Child + Infant;
        document.getElementById("txtTotalTravelers").value = (TotTravelers + " Travellers");
    }
}


function process2(s) {
    var Adult = parseInt(document.getElementById("ddlAdult").value);
    var Child = parseInt(document.getElementById("ddlChild").value);
    var Infant = parseInt(document.getElementById("ddlInfant").value);
    Child += s;
    var total = Adult + Child;
    if (total <= 9 && Child >= 0) {
        document.getElementById("ddlChild").value = Child;
        var TotTravelers = Adult + Child + Infant;
        document.getElementById("txtTotalTravelers").value = (TotTravelers + " Travellers");
    }
}


function process3(sh) {
    var Adult = parseInt(document.getElementById("ddlAdult").value);
    var Infant = parseInt(document.getElementById("ddlInfant").value);
    var Child = parseInt(document.getElementById("ddlChild").value);
    Infant += sh;
    if (Infant <= Adult && Infant >= 0) {
        document.getElementById("ddlInfant").value = Infant;
        var TotTravelers = Adult + Child + Infant;
        document.getElementById("txtTotalTravelers").value = (TotTravelers + " Travellers");
    }
}


$(document).ready(function () {
    if ($('div.trav_toggle').length > 0) {
        $('div.trav_toggle').click(function () {
            if ($(this).hasClass('open')) {
                $(this).removeClass('open');
                $(this).addClass('close');
                $(this).next().slideDown(100);
                return false;
            } else {
                $(this).removeClass('close');
                $(this).addClass('open');
                $(this).next().slideUp(100);
                return false;
            }
        });
    }
});

//traveller counter end//
