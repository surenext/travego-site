$('.airlies-slider').owlCarousel({
    loop: true,
    margin: 0,
    dots: false,
    autoplay: true,
    nav: true,
    responsive: {
        0: {
            items: 2
        },
        600: {
            items: 2
        },
        1000: {
            items: 5
        }
    }
})
$('.htlpackage').owlCarousel({
    loop: false,
    autoplay: true,
    margin: 10,
    dots: false,
    nav: false,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 3
        }
    }
})

//hotel list slider start//
$('.hotel-list-slider').owlCarousel({
    loop: true,
    lazyLoad: true,
    autoplay: true,
    items: 5,
    margin: 20,
    dots: false,
    center: false,
    nav: true,
    smartSpeed: 800,
    responsive: {
        0: {
            items: 1.4,
            stagePadding: 0,
            nav: false,
            center: true
        },
        420: {
            items: 2.4,
            nav: false,
        },
        600: {
            items: 3,
        },
        1000: {
            items: 3
        }
    }
});
//hotel list slider end//
//hotel check in date js start//

$('#checkin-hotel').datepicker({
    format: 'dd-mm-yyyy',
    autoclose: true,
    todayBtn: true,
    minDate: '+1d',

})
//hotel check in date js end//

//hotel check out date js start//

$('#checkout-hotel').datepicker({
    format: 'dd-mm-yyyy',
    autoclose: true,
    todayBtn: true,
    minDate: '+1d',

})
//hotel check out date js end//

//hotel detail page start//
$('#hotel-detail-slider').owlCarousel({
    loop: true,
    lazyLoad: true,
    autoplay: true,
    items: 5,
    margin: 20,
    dots: false,
    center: false,
    nav: true,
    smartSpeed: 800,
    responsive: {
        0: {
            items: 1,
            stagePadding: 0,
            nav: true,
            center: true
        },
        420: {
            items: 1,
            nav: true,
        },
        600: {
            items: 1,
            nav: true,
        },
        1000: {
            items: 1,
            nav: true,
        }
    }
});
//hotel detail page end//
//scrool to top package tabs start//
var elementPosition = $('#fixTabsss').offset();
$(window).scroll(function () {
    if ($(window).scrollTop() > elementPosition.top) {
        $('#fixTabsss').addClass('fixedhotel_type')
    } else {
        $('#fixTabsss').removeClass('fixedhotel_type')
    }
});
//scrool to top package tabs end//

//adult, child, infant number counter start//
//$(document).on("click", '.minus', function () {
//    var $input = $(this).parent().find('input');
//    var count = parseInt($input.val()) - 250;
//    count = count < 1 ? 0 : count;
//    $input.val(count);
//    $input.change();
//    return false;
//});
//$(document).on("click", '.plus', function () {
//    var $input = $(this).parent().find('input');
//    $input.val(parseInt($input.val())- 70);
//    $input.change();
//    return false;
//});

//adult, child, infant number counter end//


//child age append toggle start//

$(document).ready(function () {
    $("#travel-open_btn").click(function () {
        $("#travel-search_open").toggle();
    });
    $('#close-btn-traveller').click(function () {
        $('#travel-search_open').hide();
    });
});


// $(document).ready(function () {
//     $('#addChild_option').click(function () {
//             $('.Counter_list_append').append(`<div class='addpass_hotel col-lg-4 col-6 col-md-3'>
//                                 <select class='form-select frmslct'>
//                                     <option selected>Child Age</option>
//                                     <option value=''>1</option>
//                                     <option value=''>2</option>
//                                     <option value=''>3</option>
//                                   </select>


//                             </div>`);

//         }
//     );

//     $(document).on('click', '.closepass_hotel', function () {
//         $(this).parents('.addpass_hotel').remove();

//     }) 

// });

//child age append toggle start//

function countAllTraveller() {
    let ctcount = parseInt($(".add-room-adults").val()) + parseInt($(".add-room-child").val());
    $(".count-traveller").text(ctcount + " Travellers");

}
// $(".count-rooms").text(ctcount + " Rooms");


function bookRoomChildsHtml(bookingRoomHtml) {
    var bookingRoomHtml = '';
    bookingRoomHtml += '<div class="col-sm-6 col-md-4 col-xs-6">';
    bookingRoomHtml += '<div class="form-group">';
    bookingRoomHtml += '<label for=""><small class="small">Child </small> Age </label>';
    bookingRoomHtml +=
        '<select title="-- Child 2 --" data-size="5" class="form-control frmselect input-sm" data-style="btn btn-gray btn-border hoverable show-tick"  name="Room0_Adult">';
    bookingRoomHtml += '<option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option>';
    bookingRoomHtml += '</select>';
    bookingRoomHtml += '</div>';
    bookingRoomHtml += '</div>';
    return bookingRoomHtml;

}

$(document).on('click', '.remove-rooms', function (e) {
    var ariticalRoomId = $('#' + $('.serch-room-count').find('.form-group').data('travellers-rooms'));
    var bookingArticalClass = ariticalRoomId.find('.booking-modal-room-artical');
    $(this).closest(bookingArticalClass).remove();
    countAllTraveller();
    e.preventDefault();
    // var rowNum = 0;
});
$(".action-control .input-text").on("change", function () {
    countAllTraveller();
})
$('.add-room-child').on('change', function (e) {
    var $this = $(this);
    var selectRoomId = $this.data('room-id');
    // console.log('' + selectRoomId);
    $('#' + selectRoomId).find('.add-child-counts').remove();
    $('#' + selectRoomId).append('<div class="col-sm-12 add-child-counts "><div class="row"></div></div>');
    for (var list = 0; list < $this.val(); list++) {
        $('#' + selectRoomId).find('.add-child-counts').find('.row').append(bookRoomChildsHtml(
            'bookingRoomHtml'));
    }
});


//select room apend div start//
$(document).ready(function () {
    $('#selectroom_btn').click(function () {
        $('#select-room-block').show();
    });

    $('#select_box_close').click(function () {
        $('#select-room-block').hide();
    });

});
//select room div end//


//similar hotel slider start//
$('.Similarhotelsliders').owlCarousel({
    loop: true,
    lazyLoad: true,
    autoplay: true,
    items: 5,
    margin: 20,
    dots: false,

    center: false,
    nav: true,
    smartSpeed: 800,
    responsive: {
        0: {
            items: 1,
            stagePadding: 0,
            nav: false,
            center: true
        },
        420: {
            items: 1,
            nav: false,
        },
        600: {
            items: 3,
        },
        1000: {
            items: 3
        }
    }
});

//similar hotel slider end//







