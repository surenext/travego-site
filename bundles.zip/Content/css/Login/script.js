function openCity(evt, cityName) {
    var i, tabBehaviour, tabActivity;
    tabBehaviour = document.getElementsByClassName("tabBehaviour");
    for (i = 0; i < tabBehaviour.length; i++) {
        tabBehaviour[i].style.display = "none";
    }
    tabActivity = document.getElementsByClassName("tabActivity");
    for (i = 0; i < tabActivity.length; i++) {
        tabActivity[i].className = tabActivity[i].className.replace(" login-active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " login-active";
}

function showpass() {
    var x = document.getElementById("passinpt");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}