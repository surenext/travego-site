var minBudget = 0;
var maxBudget = 0; var specList = "";var daysList = "";
//traveller counter start//
function process(v) {
    var Adult = parseInt(document.getElementById("ddlAdult").value);
    var Child = parseInt(document.getElementById("ddlChild").value);
    var Infant = parseInt(document.getElementById("ddlInfant").value);
    Adult += v;
    var total = Adult + Child;
    if (total <= 9 && Adult >= 1) {
        document.getElementById("ddlAdult").value = Adult;
        if (Infant > Adult) {
            document.getElementById("ddlInfant").value = Adult;
        }
        var TotTravelers = Adult + Child + Infant;
        document.getElementById("txtTotalTravelers").value = (TotTravelers + " Travellers");
    }
}


function process2(s) {
    var Adult = parseInt(document.getElementById("ddlAdult").value);
    var Child = parseInt(document.getElementById("ddlChild").value);
    var Infant = parseInt(document.getElementById("ddlInfant").value);
    Child += s;
    var total = Adult + Child;
    if (total <= 9 && Child >= 0) {
        document.getElementById("ddlChild").value = Child;
        var TotTravelers = Adult + Child + Infant;
        document.getElementById("txtTotalTravelers").value = (TotTravelers + " Travellers");
    }
}


function process3(sh) {
    var Adult = parseInt(document.getElementById("ddlAdult").value);
    var Infant = parseInt(document.getElementById("ddlInfant").value);
    var Child = parseInt(document.getElementById("ddlChild").value);
    Infant += sh;
    if (Infant <= Adult && Infant >= 0) {
        document.getElementById("ddlInfant").value = Infant;
        var TotTravelers = Adult + Child + Infant;
        document.getElementById("txtTotalTravelers").value = (TotTravelers + " Travellers");
    }
}


$(document).ready(function () {
    if ($('div.trav_toggle').length > 0) {
        $('div.trav_toggle').click(function () {
            if ($(this).hasClass('open')) {
                $(this).removeClass('open');
                $(this).addClass('close');
                $(this).next().slideDown(100);
                return false;
            } else {
                $(this).removeClass('close');
                $(this).addClass('open');
                $(this).next().slideUp(100);
                return false;
            }
        });
    }
    $('.spec-list input:checked').each(function (index, value) {
        if (specList == "") {
            specList = specList + $(this).attr('data-val');
        } else {
            specList = specList + "," + $(this).attr('data-val');
        }
    });   


    $('.budget-chkbox input:checked').each(function (index, value) {
        if (maxBudget == "") {
            maxBudget = specList + $(this).attr('data-val');
        } else {
            maxBudget = specList + "," + $(this).attr('data-val');
        }
    });


    $('.days-chkbox input:checked').each(function (index, value) {
        if (daysList == "") {
            daysList = daysList + $(this).attr('data-max');
        } else {
            daysList = daysList + "," + $(this).attr('data-max');
        }
    });




    getPackages();
});

function getPackages() {

    var destiantion = document.getElementById("destinations-iinput").value;
    $.ajax({
        type: "POST",
        url: "/Package/GetPackages",
        data: '{ "Destination": "' + destiantion + '","MinBudget": "' + minBudget + '","MaxBudget": "' + maxBudget + '","NoOfNights":"' + daysList + '","SpecList":"' + specList + '"}',
        async: true,
        contentType: "application/json; charset=utf-8",
        dataType: "html",
        success: function (r) {
            $("#package-list").html(r);
        }
    }).then(function () {
        $("#loadermain").addClass("hidden")

    });
}

$('.spec-list :checkbox').click(function (e) {
    $("#loadermain").removeClass("hidden")
    var selected = [];
    specList = "";
    $('.spec-list input:checked').each(function (index, value) {
        if (specList == "") {
            specList = specList + $(this).attr('data-val');
        } else {
            specList = specList + "," + $(this).attr('data-val');
        }
    });
    getPackages();
});

$('.budget-chkbox :checkbox').click(function (e) {
    $("#loadermain").removeClass("hidden")    
    minBudget = 0;
    maxBudget = 10000;
    $('.budget-chkbox input:checked').each(function (index, value) {
        var min = $(this).attr('data-min');
        if (min > minBudget) {
            minBudget = min;
        }
        var max = $(this).attr('data-max');
        if (max > maxBudget) {
            maxBudget = max;
        }
    });
    getPackages();
});

//$('.days-chkbox :checkbox').click(function (e) {         
//    $('.days-chkbox input:checked').each(function (index, value) {
//        if (days-chkbox == "") {
//            specList = specList + $(this).attr('data-val');
//        } else {
//            specList = specList + "," + $(this).attr('data-val');
//        }
//    });
//    getPackages();
//});

$('.days-chkbox :checkbox').click(function (e) {
    $("#loadermain").removeClass("hidden")
    daysList = "";
    $('.days-chkbox :checkbox:checked').each(function (index, value) {
        if (daysList === "") {
            daysList = daysList + $(this).attr('data-max');
        } else {
            daysList = daysList + "," + $(this).attr('data-max');
        }
    });

    
    getPackages(); 
});





$("#destinations-iinput").autocomplete({
    minLength: 2,
    classes: {
        "ui-autocomplete": "dropdown-menu",
    },
    select: function (sdata, ui) { document.getElementById("destinations-iinput").value = ui.item.label; getPackages() },
    source: function (request, responce) {
        debugger;
        $.ajax({
            url: "/Home/GetCityList",
            type: "POST",
            dataType: "json",
            async: true,
            data: { searchText: request.term, Type: 'Package' },
            success: function (data) {
                var customer = new Array();
                for (var i = 0; i < data.list.length; i++) {
                    customer[i] = { label: data.list[i].Name, Id: i };
                }
                responce(customer);
            },
            error: function (err) {
                alert('error');
            }
        });
    }
}).data("ui-autocomplete")._renderItem = function (ul, item) {
    return $("<li ></li>")
        .addClass(item.customClass) //item based custom class to li here
        .append("<a href='#' <i class='autodataincom-divv'> " + item.label + "</a>")
        .data("ui-autocomplete-item", item)
        .appendTo(ul);
};
//traveller counter end//

function clearFilter() {

    var destiantion = '';
    debugger;
    jQuery("#filterDiv").find(':input').each(function () {
        switch (this.type) {
            case 'password':
            case 'text':
            case 'textarea':
            case 'file':
            case 'select-one':
            case 'select-multiple':
            case 'date':
            case 'number':
            case 'tel':
            case 'email':
                jQuery(this).val('');
                break;
            case 'checkbox':
            case 'radio':
                this.checked = false;
                break;
        }
    });
    specList = '';
    $.ajax({
        type: "POST",
        url: "/Package/GetPackages",
        data: '{ "Destination": "' + destiantion + '","MinBudget": "' + 0 + '","MaxBudget": "' + 0 + '","SpecList":"' + specList + '"}',
        async: true,
        contentType: "application/json; charset=utf-8",
        dataType: "html",
        success: function (r) {
            $("#package-list").html(r);
        }
    }).then(function () {
        $("#loadermain").addClass("hidden")
    });
}
function clearName() {
    document.getElementById("destinations-iinput").value = null;
    getPackages();
}