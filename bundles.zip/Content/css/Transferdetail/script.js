$('.cabdateSelect').datepicker({
    format: 'dd-mm-yyyy',
    autoclose: true,
    todayBtn: true,
    changeMonth: true,
    changeYear: true
});
//hotel detail page start//
$('#transfer-detail-slider').owlCarousel({
    loop: true,
    lazyLoad: true,
    autoplay: true,
    items: 5,
    margin: 20,
    dots: false,
    center: false,
    nav: true,
    smartSpeed: 800,
    responsive: {
        0: {
            items: 1,
            stagePadding: 0,
            nav: true,
            center: true
        },
        420: {
            items: 1,
            nav: true,
        },
        600: {
            items: 1,
            nav: true,
        },
        1000: {
            items: 1,
            nav: true,
        }
    }
});
//hotel detail page end//

//scrool to top package tabs start//
var elementPosition = $('#fixTabsss').offset();
$(window).scroll(function () {
    if ($(window).scrollTop() > elementPosition.top) {
        $('#fixTabsss').addClass('fixedhotel_type')
    } else {
        $('#fixTabsss').removeClass('fixedhotel_type')
    }
});
//scrool to top package tabs end//