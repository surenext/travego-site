// visa type tabs
$.ajax({
    url: '/Visa/GetCountry',
    type: 'POST',
    dataType: 'html',
    success: function (d) {
        
        var country = $.parseJSON(d);

        $.each(country.Countries, function (i, item) {

            if (item.ToCountryName != null && item.ToCountryName != "") {
                $("#TravelCountry").append('<option value="' + item.ToCountryId + '#' + item.SEOURL + '">' + item.ToCountryName + '</option>');
            }

        });
    },
    error: function () {
        alert('Error!');
    }

});

function redirectVisa() {
    window.location.href = '/visa-detail/' + document.getElementById("TravelCountry").value.split('#')[1];
}
//function OpenVisaHere(evt, cityName) {
//    var i, visdetail_content, tabsVisatype;
//    visdetail_content = document.getElementsByClassName("visdetail_content");
//    for (i = 0; i < visdetail_content.length; i++) {
//      visdetail_content[i].style.display = "none";
//    }
//    tabsVisatype = document.getElementsByClassName("tabsVisatype");
//    for (i = 0; i < tabsVisatype.length; i++) {
//      tabsVisatype[i].className = tabsVisatype[i].className.replace(" current", "");
//    }
//    document.getElementById(cityName).style.display = "block";
//    evt.currentTarget.className += " current";
//  }